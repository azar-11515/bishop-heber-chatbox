# Hackathon Chatbot 🤖

A simple AI chatbot built with Streamlit + Hugging Face models.

## 🚀 How to Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 🌐 Deployment
This repo is ready for **Streamlit Cloud** deployment.
