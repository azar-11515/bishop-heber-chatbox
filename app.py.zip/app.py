import streamlit as st
from transformers import pipeline

st.set_page_config(page_title="Hackathon Chatbot", page_icon="🤖")
st.title("🤖 Hackathon Chatbot")
st.write("Hi! I’m your friendly chatbot. Ask me anything!")

# Load a small chatbot model (free Hugging Face model)
chatbot = pipeline("text2text-generation", model="google/flan-t5-small")

# User input box
user_input = st.text_input("You:", "")

# If user types something, generate response
if user_input:
    response = chatbot(user_input, max_length=200, do_sample=True)
    st.write("**Bot:**", response[0]['generated_text'])
